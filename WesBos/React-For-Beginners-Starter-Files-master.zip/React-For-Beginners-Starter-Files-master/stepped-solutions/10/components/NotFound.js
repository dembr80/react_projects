import React from "react";

const NotFound = () => (
  <div>
    <h2>Not Found!?!!!!1111</h2>
  </div>
);

export default NotFound;
